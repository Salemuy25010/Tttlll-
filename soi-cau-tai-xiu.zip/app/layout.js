export const metadata = {
  title: "Soi Cầu Tài Xỉu",
  description: "Phân tích kết quả tài xỉu",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}