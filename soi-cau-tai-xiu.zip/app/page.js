"use client";
import React, { useState } from "react";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  LineElement,
  PointElement,
  CategoryScale,
  LinearScale,
} from "chart.js";

ChartJS.register(LineElement, PointElement, CategoryScale, LinearScale);

export default function SoiCauTaiXiu() {
  const [results, setResults] = useState([]);
  const [input, setInput] = useState("");

  const handleAddResult = () => {
    const formattedInput = input.toLowerCase();
    if (formattedInput === "tài" || formattedInput === "xỉu") {
      setResults([...results, formattedInput]);
      setInput("");
    }
  };

  const getSuggestion = () => {
    const len = results.length;
    if (len < 2) return "Chưa đủ dữ liệu";
    const last = results[len - 1];
    const prev = results[len - 2];
    const isChain = last === prev;
    return isChain
      ? `Nên theo cầu: ${last.toUpperCase()}`
      : `Nên đảo cầu: ${last === "tài" ? "XỈU" : "TÀI"}`;
  };

  const getStats = () => {
    const tai = results.filter((r) => r === "tài").length;
    const xiu = results.filter((r) => r === "xỉu").length;
    return { tai, xiu };
  };

  const chartData = {
    labels: results.map((_, i) => `Phiên ${i + 1}`),
    datasets: [
      {
        label: "Tài (1) / Xỉu (0)",
        data: results.map((r) => (r === "tài" ? 1 : 0)),
        fill: false,
        borderColor: "#2563eb",
        tension: 0.3,
      },
    ],
  };

  return (
    <main className="p-4 space-y-4 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold">Soi Cầu Tài Xỉu</h1>
      <div className="space-y-2">
        <input
          className="border px-3 py-1 w-full rounded"
          placeholder="Nhập kết quả: Tài hoặc Xỉu"
          value={input}
          onChange={(e) => setInput(e.target.value)}
        />
        <button
          className="bg-blue-600 text-white px-4 py-2 rounded"
          onClick={handleAddResult}
        >
          Thêm
        </button>
        <p className="text-sm">Gợi ý phiên sau: {getSuggestion()}</p>
        <p className="text-sm">
          Tổng Tài: {getStats().tai} | Tổng Xỉu: {getStats().xiu}
        </p>
      </div>
      <div>
        <Line data={chartData} />
      </div>
    </main>
  );
}